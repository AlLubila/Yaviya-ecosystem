# YAVIYA — site original, installation indépendante

Restauration de la version 31 du site YAVIYA « Votre marché, à portée de main », depuis les sources `36ee877a339956ae0598c8fa830df0aeaf8cd233`. Ce projet conserve les pages, les photos locales et les parcours acheteur, vendeur, livreur et administrateur. Il remplace la vitrine simplifiée introduite le 3 octobre.

## Ce qui est conservé

Catalogue multi-vendeurs, catégories, favoris, comparateur, galerie de photos, recherche, panier, deux marchés, français/anglais, communes de Kinshasa et Lubumbashi, FAQ, assistant local, inscriptions vendeur/livreur, vérification manuelle, commandes partagées, disponibilité et rémunération indicative du livreur, messages, preuve de livraison privée et évaluations. Les règles métier du backend original sont conservées.

## Installation locale

Node.js **24** est requis.

```bash
npm ci
npm run dev
```

Ouvrir http://127.0.0.1:3000. Les migrations sont appliquées automatiquement au démarrage local. La base SQLite se trouve dans `.local/`, exclue de Git. La connexion utilise un e-mail ou un téléphone et un mot de passe de 12 à 128 caractères. Le profil conserve son formulaire d'origine et ses identifiants YVC/YVYS/YVYC.

```bash
npm test
npm run build
npm start
```

## Activer l'installation Vercel

Le projet GitHub doit être relié au projet Vercel `yaviyaecosystem`, avec la racine du dépôt comme Root Directory. `vercel.json` configure `npm run build`, le dossier `dist` et la fonction API indépendante. Utiliser Node.js 24.

1. Créer ou connecter une base **Turso/libSQL** dédiée à cette installation. Elle conserve le SQL SQLite du backend original et évite une réécriture des règles métier.
2. Ajouter `TURSO_DATABASE_URL` et `TURSO_AUTH_TOKEN` aux environnements Production et Preview du projet Vercel. Idéalement utiliser une base distincte pour les previews ; ne pas exposer ces valeurs au frontend.
3. Copier `.env.example` vers `.env` dans un terminal local de confiance et renseigner les mêmes valeurs, puis exécuter `npm run db:migrate`. La migration est idempotente et refuse les erreurs plutôt que de continuer avec un schéma partiel.
4. Pour créer le propriétaire administrateur, renseigner un identifiant distinct `OWNER_LOGIN` et un mot de passe choisi par le propriétaire dans `.env`, puis exécuter `npm run db:owner`. Cette opération ne peut pas être effectuée depuis le navigateur. Supprimer ensuite ces deux valeurs de `.env` ; elles ne sont pas nécessaires au serveur.
5. Déployer la branche validée, puis vérifier la connexion, le profil, les documents, commandes et messages sur la preview avant la fusion dans `main`.

**Sans la base et ses variables, la vitrine peut se charger mais les API répondent 503. Cela ne constitue pas une installation complète.** Aucun stockage temporaire en mémoire ou sur `/tmp` n'est utilisé comme base de production. Le build n'a pas besoin de secrets et ne modifie pas la base.

## Architecture

| Emplacement | Rôle |
| --- | --- |
| `frontend/` | Pages, scripts classiques, styles et 34 images originales locales |
| `api/handler.js` | Fonction Vercel : conversion HTTP vers les gestionnaires existants |
| `backend/application.js` | Session indépendante et identité injectée côté serveur |
| `backend/auth.js` | Comptes, mots de passe scrypt, sessions serveur, déconnexion et limitation des tentatives |
| `backend/database.js` | Adaptation D1 vers libSQL : requêtes, transactions et stockage privé des fichiers |
| `backend/worker/` | Gestionnaires métier de la version 31, avec identités YAVIYA indépendantes |
| `database/migrations/` | Migrations originales et tables des accès indépendants |
| `scripts/` | Serveur local, build, migrations, création propriétaire et contrôles |
| `tests/independent.test.mjs` | Tests des accès privés et du parcours partagé à quatre comptes distincts |

Les documents privés sont enregistrés en BLOB dans la base, avec leurs types MIME. Ils ne sont pas copiés dans `dist`, ni exposés sous une URL publique ; les routes conservent les contrôles du backend original. Pour un volume important, un stockage de fichiers privé séparé devra remplacer cet adaptateur. Les limites de téléversement de la plateforme et de la base devront être vérifiées sur le projet actif avant l'ouverture publique ; les contrôles existants de 8 Mo et de signature des fichiers sont conservés.

## Limites de la version originale et de cette restauration

Cette installation est indépendante de ChatGPT : elle n'utilise ni sa connexion, ni sa base, ni ses fichiers privés, et n'appelle pas le site original. Elle démarre avec une **nouvelle base**. Les profils, commandes, messages et documents déjà enregistrés dans ChatGPT Sites ne sont pas exportés ni migrés par ce projet.

Les produits et boutiques initiaux sont illustratifs. Les paiements Mobile Money/carte, l'escrow financier, les reversements automatiques, les abonnements payants, Google et l'envoi d'e-mails ne sont pas activés. La connexion indépendante n'ajoute pas de vérification e-mail/SMS ni de récupération automatique du mot de passe. Les paiements à réception et règlements manuels conservent leurs déclarations de suivi, sans transfert automatique de fonds. L'assistant reste celui du site original.

Validation locale : syntaxe des sources, fichiers référencés, migrations, transactions atomiques, session/CSRF, isolation des profils, refus d'identité falsifiée, pièces privées, validation manuelle vendeur/livreur, création de produit, commande idempotente, acceptation, préparation, affectation livreur, preuve privée, réception et notes vendeur/livreur. La configuration et les ressources réelles Vercel/Turso doivent encore être activées et testées à distance. Aucun test visuel navigateur n'a encore été exécuté dans cet environnement.

## Connexion Google / Gmail
Créer un client OAuth Google de type Web. Ajouter exactement GOOGLE_REDIRECT_URI aux URI autorisés, puis définir GOOGLE_CLIENT_ID, GOOGLE_CLIENT_SECRET et GOOGLE_REDIRECT_URI sur Vercel. Le secret reste côté serveur. Aucun accès Gmail ni lecture des messages : seuls openid, email et profile sont demandés. Les comptes Google sont séparés des comptes par mot de passe pour éviter un rattachement par e-mail non vérifié.
