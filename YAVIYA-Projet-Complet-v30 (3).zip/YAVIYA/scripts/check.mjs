import { readFile, readdir } from 'node:fs/promises';
import { spawnSync } from 'node:child_process';
import assert from 'node:assert/strict';
const html = await readFile('frontend/index.html', 'utf8');
for (const directory of ['frontend', 'backend', 'backend/worker', 'api', 'scripts']) {
  for (const file of (await readdir(directory)).filter(f => /\.(m?js)$/.test(f))) {
    const result = spawnSync(process.execPath, ['--check', `${directory}/${file}`], { encoding: 'utf8' });
    assert.equal(result.status, 0, `${directory}/${file}: ${result.stderr}`);
  }
}
for (const page of ['index.html', 'congo.html', 'aide.html', 'confidentialite.html', 'publicite.html']) {
  const content = await readFile(`frontend/${page}`, 'utf8');
  for (const match of content.matchAll(/(?:src|href)=["']([^"']+)["']/g)) {
    const path = match[1].split('?')[0];
    if (/^[a-zA-Z0-9_.-]+\.(?:html|js|css|jpg|png|webp)$/.test(path)) await readFile(`frontend/${path}`);
  }
}
assert.ok(html.includes('auth-independent.js'));
assert.equal(JSON.parse(await readFile('vercel.json', 'utf8')).outputDirectory, 'dist');
console.log('Sources originales, fichiers référencés et configuration Vercel vérifiés.');
