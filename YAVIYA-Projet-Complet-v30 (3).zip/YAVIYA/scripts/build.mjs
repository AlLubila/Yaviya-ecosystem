import { cp, rm } from 'node:fs/promises';
await rm('dist', { recursive: true, force: true });
await cp('frontend', 'dist', { recursive: true });
console.log('Site YAVIYA original compilé dans dist/. Backend : api/handler.js.');
