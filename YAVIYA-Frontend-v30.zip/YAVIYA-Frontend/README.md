# YAVIYA — Code frontend, version 30

Export de la version publiée le 3 octobre 2026, incluant les corrections de l’espace livreur.

## Contenu

Le dossier `frontend/` contient le code HTML, CSS, JavaScript et toutes les images publiques. Les fichiers sont les sources réellement utilisées par le site, sans modification de leur ordre de chargement.

- `index.html` : page principale et chargement des modules.
- `style.css` : présentation et adaptation mobile.
- `app.js`, `marketplace.js` : catalogue et fonctions de base.
- `customer.js`, `profile-commerce.js` : profil et navigation des comptes.
- `registration-categories.js` : inscription par étapes et catégories.
- `account-verification-flows.js` : dossiers vendeur et livreur.
- `shared-commerce.js` : commandes partagées, missions et rémunération livreur.
- `courier-reviews.js` : évaluations et discussion livreur–administration.
- `product-gallery.js` : photos multiples des produits.
- `aide.html`, `confidentialite.html`, `publicite.html`, `congo.html` : pages complémentaires.
- Les autres modules JavaScript et images conservent leur rôle dans la version publiée.

## Lancer le frontend en local

Avec Python 3 installé, ouvrez un terminal dans `frontend/`, puis lancez :

```sh
python -m http.server 8000
```

Ouvrez ensuite http://localhost:8000 dans votre navigateur. Évitez d’ouvrir directement le fichier HTML avec `file://`.

## Connexion au backend

Cet export contient uniquement le frontend. Les fonctionnalités connectées appellent des URL relatives `/api/...` sur le même domaine : profil, vérification, catalogue partagé, commandes, preuves de livraison, discussions, évaluations et Yavicoins.

Le serveur local ci-dessus affiche les pages et les éléments publics. Il ne fournit pas ces API : les actions connectées nécessitent le backend YAVIYA et son authentification. Les messages d’indisponibilité des services en local sont donc attendus. Les comptes et missions ne sont pas simulés dans cet export.

Pour le parcours complet, le développeur devra servir les fichiers et les API derrière une même origine et adapter l’authentification si le projet quitte son hébergement actuel. Le backend existant identifie les utilisateurs à partir de la connexion fournie par cet hébergement ; le frontend seul ne remplace pas ce mécanisme.

Les paiements électroniques et l’escrow ne sont pas activés. Les commandes actuelles utilisent la déclaration du paiement en espèces et des règlements manuels.

## Version source

Version publiée : 30.
Commit source : abdf4fbee5a2fbab0387cd0ce2435498b64073fc.

Aucun code serveur, document d’identité privé, donnée de compte ni identifiant secret n’est inclus.
